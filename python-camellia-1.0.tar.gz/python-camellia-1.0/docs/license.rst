Licenses
========

python-camellia is dual licensed:

* The Python code is MIT licensed,
* the C code is 2-Clause-BSD licensed.
