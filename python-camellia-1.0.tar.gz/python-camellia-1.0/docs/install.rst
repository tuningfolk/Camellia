Installation
============

Install with `pip <https://pip.pypa.io/en/stable/installing/>`_: 

.. code:: shell

   $ pip install python-camellia
